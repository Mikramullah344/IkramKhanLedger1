package pk.ikramkhan.ledger

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.*
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Customer(val id: Long, val name: String, val father: String, val address: String, val phone: String)

class LedgerDb(ctx: Context) : SQLiteOpenHelper(ctx, "ikram_ledger.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, father TEXT, address TEXT, phone TEXT)""")
        db.execSQL("""CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL, kind TEXT NOT NULL, title TEXT, amount REAL NOT NULL, note TEXT, date TEXT NOT NULL)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addCustomer(name:String, father:String, address:String, phone:String) {
        writableDatabase.execSQL("INSERT INTO customers(name,father,address,phone) VALUES(?,?,?,?)", arrayOf(name,father,address,phone))
    }
    fun customers(): List<Customer> {
        val out= mutableListOf<Customer>()
        readableDatabase.rawQuery("SELECT id,name,father,address,phone FROM customers ORDER BY name", null).use {
            while(it.moveToNext()) out.add(Customer(it.getLong(0),it.getString(1),it.getString(2) ?: "",it.getString(3) ?: "",it.getString(4) ?: ""))
        }; return out
    }
    fun addEntry(cid:Long, kind:String, title:String, amount:Double, note:String) {
        val date=SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        writableDatabase.execSQL("INSERT INTO entries(customer_id,kind,title,amount,note,date) VALUES(?,?,?,?,?,?)", arrayOf(cid,kind,title,amount,note,date))
    }
    fun totals(cid:Long?=null): DoubleArray {
        val where=if(cid==null) "" else " WHERE customer_id=$cid"
        val c=readableDatabase.rawQuery("SELECT kind, SUM(amount) FROM entries$where GROUP BY kind",null)
        var sales=0.0; var advance=0.0; var payments=0.0; var discounts=0.0
        c.use { while(it.moveToNext()) when(it.getString(0)) {
            "SALE" -> sales=it.getDouble(1)
            "ADVANCE" -> advance=it.getDouble(1)
            "PAYMENT" -> payments=it.getDouble(1)
            "DISCOUNT" -> discounts=it.getDouble(1)
        }}
        return doubleArrayOf(sales,advance,payments,discounts,sales-advance-payments-discounts)
    }
    fun entries(cid:Long): List<String> {
        val a= mutableListOf<String>()
        readableDatabase.rawQuery("SELECT date,kind,title,amount,note FROM entries WHERE customer_id=? ORDER BY id DESC", arrayOf(cid.toString())).use {
            while(it.moveToNext()) {
                val label=when(it.getString(1)){"SALE"->"سامان";"ADVANCE"->"ایڈوانس";"PAYMENT"->"وصولی";else->"کٹوتی"}
                a.add("${it.getString(0)} | $label | ${it.getString(2)} | ${it.getDouble(3).toLong()} روپے"+if(it.getString(4).isNullOrBlank()) "" else " | ${it.getString(4)}")
            }
        }; return a
    }
    fun backupJson(): String {
        val root=JSONObject(); val cs=JSONArray(); val es=JSONArray()
        readableDatabase.rawQuery("SELECT id,name,father,address,phone FROM customers",null).use { while(it.moveToNext()) {
            cs.put(JSONObject().put("id",it.getLong(0)).put("name",it.getString(1)).put("father",it.getString(2)).put("address",it.getString(3)).put("phone",it.getString(4)))
        }}
        readableDatabase.rawQuery("SELECT customer_id,kind,title,amount,note,date FROM entries",null).use { while(it.moveToNext()) {
            es.put(JSONObject().put("customer_id",it.getLong(0)).put("kind",it.getString(1)).put("title",it.getString(2)).put("amount",it.getDouble(3)).put("note",it.getString(4)).put("date",it.getString(5)))
        }}
        return root.put("customers",cs).put("entries",es).toString(2)
    }
    fun restoreJson(data:String) {
        val root=JSONObject(data); val db=writableDatabase
        db.beginTransaction()
        try {
            db.delete("entries",null,null); db.delete("customers",null,null)
            val cs=root.getJSONArray("customers")
            for(i in 0 until cs.length()) { val x=cs.getJSONObject(i)
                db.execSQL("INSERT INTO customers(id,name,father,address,phone) VALUES(?,?,?,?,?)", arrayOf(x.getLong("id"),x.getString("name"),x.optString("father"),x.optString("address"),x.optString("phone")))
            }
            val es=root.getJSONArray("entries")
            for(i in 0 until es.length()) { val x=es.getJSONObject(i)
                db.execSQL("INSERT INTO entries(customer_id,kind,title,amount,note,date) VALUES(?,?,?,?,?,?)", arrayOf(x.getLong("customer_id"),x.getString("kind"),x.optString("title"),x.getDouble("amount"),x.optString("note"),x.getString("date")))
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
}

class MainActivity : Activity() {
    private lateinit var db: LedgerDb
    private lateinit var root: LinearLayout
    private val pickBackup=41
    private val saveBackup=42
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db=LedgerDb(this); pinScreen() }
    private fun pinScreen() {
        val box=LinearLayout(this).apply { orientation=1; gravity=Gravity.CENTER; setPadding(28,28,28,28) }
        box.addView(label("اکرام خان کارپوریشن",24,true))
        val pin=EditText(this).apply { hint="چار ہندسوں کا پاس ورڈ"; inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        box.addView(pin)
        box.addView(btn("داخل ہوں") { if(pin.text.toString()=="1173") home() else toast("پاس ورڈ غلط ہے") })
        setContentView(box)
    }
    private fun home() {
        root=LinearLayout(this).apply { orientation=1; setPadding(16,16,16,16) }
        val scroll=ScrollView(this); scroll.addView(root); setContentView(scroll)
        root.addView(label("اکرام خان کارپوریشن لیجر",23,true))
        val t=db.totals()
        root.addView(label("کل سامان: ${money(t[0])} روپے",17,true))
        root.addView(label("کل ایڈوانس: ${money(t[1])} روپے",16,false))
        root.addView(label("بعد کی وصولیاں: ${money(t[2])} روپے",16,false))
        root.addView(label("کل وصول شدہ: ${money(t[1]+t[2])} روپے",18,true))
        root.addView(label("کل کٹوتی / ڈسکاؤنٹ: ${money(t[3])} روپے",16,false))
        root.addView(label("کل بقایا: ${money(t[4])} روپے",19,true))
        root.addView(btn("نیا کسٹمر شامل کریں") { addCustomerDialog() })
        root.addView(btn("بیک اپ بنائیں") { createBackup() })
        root.addView(btn("بیک اپ بحال کریں") { restoreBackup() })
        root.addView(label("کسٹمرز کی فہرست",20,true))
        db.customers().forEach { c ->
            val b=btn("${c.name}  |  ${c.phone}\nبقایا: ${money(db.totals(c.id)[4])} روپے") { customerScreen(c) }
            root.addView(b)
        }
        if(db.customers().isEmpty()) root.addView(label("ابھی کوئی کسٹمر شامل نہیں کیا گیا۔",16,false))
    }
    private fun customerScreen(c:Customer) {
        val t=db.totals(c.id)
        val msg=buildString {
            append("نام: ${c.name}\nولدیت: ${c.father}\nپتہ: ${c.address}\nفون: ${c.phone}\n\n")
            append("سامان: ${money(t[0])}\nایڈوانس: ${money(t[1])}\nبعد کی وصولی: ${money(t[2])}\nکل وصول شدہ: ${money(t[1]+t[2])}\nکٹوتی: ${money(t[3])}\nبقایا: ${money(t[4])}\n\n")
            append(db.entries(c.id).joinToString("\n"))
        }
        val box=LinearLayout(this).apply { orientation=1; setPadding(16,16,16,16) }
        box.addView(label(c.name,22,true))
        box.addView(label("ولدیت: ${c.father} | پتہ: ${c.address} | فون: ${c.phone}",14,false))
        box.addView(label("سامان: ${money(t[0])} | ایڈوانس: ${money(t[1])}\nبعد کی وصولی: ${money(t[2])} | کل وصولی: ${money(t[1]+t[2])}\nکٹوتی: ${money(t[3])} | بقایا: ${money(t[4])}",16,true))
        box.addView(btn("سامان / نیا بل درج کریں") { entryDialog(c,"SALE","سامان کا نام") })
        box.addView(btn("ایڈوانس وصول کریں") { entryDialog(c,"ADVANCE","ایڈوانس کی تفصیل") })
        box.addView(btn("بعد کی رقم وصول کریں") { entryDialog(c,"PAYMENT","وصولی کی تفصیل") })
        box.addView(btn("بقایا میں سے کٹوتی / ڈسکاؤنٹ") { entryDialog(c,"DISCOUNT","کٹوتی کی وجہ") })
        box.addView(btn("رسید / کھاتہ شیئر کریں") { shareText(msg) })
        box.addView(btn("واپس") { home() })
        setContentView(ScrollView(this).apply { addView(box) })
    }
    private fun addCustomerDialog() {
        val fields=listOf("کسٹمر کا نام","ولدیت","پتہ / گاؤں","فون نمبر").map { EditText(this).apply { hint=it } }
        val box=LinearLayout(this).apply { orientation=1; fields.forEach { addView(it) } }
        AlertDialog.Builder(this).setTitle("نیا کسٹمر").setView(box).setPositiveButton("محفوظ کریں") { _,_ ->
            if(fields[0].text.isNotBlank()) { db.addCustomer(fields[0].text.toString(),fields[1].text.toString(),fields[2].text.toString(),fields[3].text.toString()); home() }
            else toast("کسٹمر کا نام لکھیں")
        }.setNegativeButton("منسوخ",null).show()
    }
    private fun entryDialog(c:Customer, kind:String, titleHint:String) {
        val title=EditText(this).apply { hint=titleHint }
        val amount=EditText(this).apply { hint="رقم (روپے)"; inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val qty=EditText(this).apply { hint="تعداد"; inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val unit=EditText(this).apply { hint="فی عدد قیمت (روپے)"; inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val note=EditText(this).apply { hint="اضافی نوٹ / کٹوتی کی وجہ (اختیاری)" }
        val box=LinearLayout(this).apply {
            orientation=1; setPadding(16,8,16,8); addView(title)
            if(kind=="SALE") { addView(qty); addView(unit) } else addView(amount)
            addView(note)
        }
        val heading=when(kind){"SALE"->"سامان درج کریں";"ADVANCE"->"ایڈوانس وصول کریں";"PAYMENT"->"رقم وصول کریں";else->"بقایا میں کٹوتی درج کریں"}
        AlertDialog.Builder(this).setTitle(heading).setView(box).setPositiveButton("محفوظ کریں") { _,_ ->
            val q=qty.text.toString().toDoubleOrNull()
            val u=unit.text.toString().toDoubleOrNull()
            val value=if(kind=="SALE" && q!=null && u!=null) q*u else amount.text.toString().toDoubleOrNull()
            val itemTitle=if(kind=="SALE" && q!=null && u!=null) "${title.text} (تعداد: $q × فی عدد: ${money(u)})" else title.text.toString()
            if(value!=null && value>0) { db.addEntry(c.id,kind,itemTitle,value,note.text.toString()); customerScreen(c) } else toast(if(kind=="SALE") "تعداد اور فی عدد قیمت درست درج کریں" else "درست رقم درج کریں")
        }.setNegativeButton("منسوخ",null).show()
    }
    private fun createBackup() { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").putExtra(Intent.EXTRA_TITLE,"IkramKhanLedgerBackup.json"),saveBackup) }
    private fun restoreBackup() { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE),pickBackup) }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(resultCode==RESULT_OK && data?.data!=null) try {
        if(requestCode==saveBackup) { contentResolver.openOutputStream(data.data!!)?.use { it.write(db.backupJson().toByteArray()) }; toast("بیک اپ محفوظ ہوگیا") }
        if(requestCode==pickBackup) { val s=contentResolver.openInputStream(data.data!!)?.bufferedReader()?.readText() ?: ""; db.restoreJson(s); toast("بیک اپ بحال ہوگیا"); home() }
    } catch(e:Exception) { toast("فائل میں مسئلہ: ${e.message}") } }
    private fun shareText(s:String) { val i=Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,s); startActivity(Intent.createChooser(i,"کھاتہ شیئر کریں")) }
    private fun label(s:String,size:Float,bold:Boolean)=TextView(this).apply { text=s; textSize=size; gravity=Gravity.RIGHT; textDirection=View.TEXT_DIRECTION_RTL; setPadding(4,8,4,8); if(bold) setTypeface(null,Typeface.BOLD) }
    private fun btn(s:String, action:()->Unit)=Button(this).apply { text=s; isAllCaps=false; setOnClickListener { action() } }
    private fun money(v:Double)=String.format(Locale.US,"%,.0f",v)
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
